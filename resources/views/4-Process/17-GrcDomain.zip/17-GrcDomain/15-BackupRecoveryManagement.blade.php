<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Primary Meta Tag  -->
    <title>Compliance 360</title>
    <meta name="title" content="Saturn-V GRC Tool">
    <meta name="description" content="Zain Cloud GRC Tool">
    <!-- Boxicons Icons-->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="{{ asset('/css/style.css') }}">
</head>

<body class="profilebody">
    <div class="headersec">
        <div class="headerleft">
            <div class="headericon">
                <i class='bx bx-home'></i>
            </div>
            <div class="headertext">
                <p>العمليات</p>
                <p>Process</p>
            </div>
            <div class="headericon">
                <i class='bx bx-right-arrow-alt'></i>
            </div>
            <div class="headertext">
                <p>موارد الحوكمة والمخاطر والامتثال</p>
                <p>GRC Domain Resources</p>
            </div>
        </div>
        <div class="d-flex align-items-center gap-3">
            @include('partials.roles')
            <div class="headerright">
                <button type="button" class="button" onclick="window.location.href=('/process')">
                    <p>ارجع</p>
                    <p>Back</p>
                </button>
            </div>
        </div>
    </div>
    <div class="bodysec">
        <div class="parasec">
            <h3>Change Management</h3>
            <p>To ensure that all change in the information assets within the Member Organization follow a strict change
                control process.
            </p>
        </div>
        <div class="linksec">
            <div class="rowsec">
                <div id="VideoExplanation">
                    <div class="itemsec">
                        <i class='bx bxs-videos'></i>
                        <p>Video Explanation</p>
                    </div>
                </div>
                <div>
                    <div class="itemsec">
                        <div>
                            <div id="ImplementationDocs">
                                <i class='bx bxs-file-doc'></i>
                            </div>
                            <div id="ImplementationPdf">
                                <i class='bx bxs-file-pdf'></i>
                            </div>
                        </div>
                        <p>Implementation Templates</p>
                    </div>
                </div>
            </div>
            <div class="rowsec">
                <div id="Checklist">
                    <div class="itemsec">
                        <i class='bx bxs-file'></i>
                        <p>Checklist for CISO</p>
                    </div>
                </div>
                <div id="Glossary">
                    <div class="itemsec">
                        <img class="imgicon" src="/Images/8-TransIcon.png">
                        <p>Arabic English Glossary</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('VideoExplanation').addEventListener('click', function() {
            // URL of the PDF file
            const pdfUrl = '#';

            // Open the PDF file in a new tab
            window.open(pdfUrl, '_blank');
        });
        document.getElementById('ImplementationDocs').addEventListener('click', function() {
            // URL of the PDF file
            const pdfUrl =
                '#';

            // Open the PDF file in a new tab
            window.open(pdfUrl, '_blank');
        });
        document.getElementById('ImplementationPdf').addEventListener('click', function() {
            // URL of the PDF file
            const pdfUrl =
                '#';

            // Open the PDF file in a new tab
            window.open(pdfUrl, '_blank');
        });
        document.getElementById('Checklist').addEventListener('click', function() {
            // URL of the PDF file
            const pdfUrl = '#';

            // Open the PDF file in a new tab
            window.open(pdfUrl, '_blank');
        });
        document.getElementById('Glossary').addEventListener('click', function() {
            // URL of the PDF file
            const pdfUrl = '#';

            // Open the PDF file in a new tab
            window.open(pdfUrl, '_blank');
        });
    </script>
</body>

</html>
